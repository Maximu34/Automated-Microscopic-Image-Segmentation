"""Validate the Java feature extractor against scikit-image regionprops.

    python check_java_features.py baseline        (after running the Java tool)
"""
import sys

import cv2
import numpy as np
import pandas as pd
from skimage.measure import regionprops

from seg import config as C

method = sys.argv[1] if len(sys.argv) > 1 else "baseline"
jf = pd.read_csv(C.OUT / method / "features.csv")
rows = []
for img_id, g in jf.groupby("image"):
    lbl = cv2.imread(str(C.OUT / method / "labels" / f"{img_id}.png"), cv2.IMREAD_UNCHANGED)
    for rp in regionprops(lbl):
        rows.append({"image": img_id, "label": rp.label, "area_py": rp.area,
                     "perim_py": rp.perimeter, "ecc_py": rp.eccentricity,
                     "sol_py": rp.solidity})
m = jf.merge(pd.DataFrame(rows), on=["image", "label"])
print(f"{len(m)} objects compared ({len(jf)} from Java)")
for jc, pc in [("area", "area_py"), ("perimeter", "perim_py"),
               ("eccentricity", "ecc_py"), ("solidity", "sol_py")]:
    d = (m[jc] - m[pc]).abs()
    print(f"{jc:13s} max abs diff {d.max():.4f}   mean abs diff {d.mean():.4f}")
