"""Make a fake DSB2018-style dataset to smoke-test the pipeline (no download needed).

    python make_synthetic.py --n 60 --out ../data/raw_synthetic/stage1_train
Then:  python -m seg.data_prep --raw ../data/raw_synthetic/stage1_train

NOT for reporting results: use the real DSB2018 data for that.
"""
import argparse
from pathlib import Path

import cv2
import numpy as np


def make_one(rng, size=256):
    bright = rng.rand() < 0.7                      # fluorescence-like vs stained-like
    img = np.zeros((size, size), np.float32)
    masks = []
    for _ in range(rng.randint(10, 35)):
        c = (rng.randint(15, size - 15), rng.randint(15, size - 15))
        ax = (rng.randint(6, 16), rng.randint(5, 12))
        m = np.zeros((size, size), np.uint8)
        cv2.ellipse(m, c, ax, rng.randint(0, 180), 0, 360, 255, -1)
        for old in masks:                           # keep instances disjoint
            m[old > 0] = 0
        if m.sum() < 15 * 255:
            continue
        masks.append(m)
        img[m > 0] += rng.uniform(0.5, 1.0)
    img = cv2.GaussianBlur(img, (0, 0), 1.2)
    img = img / max(img.max(), 1e-6)
    img += rng.normal(0, 0.05, img.shape) + np.linspace(0, 0.15, size)[None, :]   # noise + uneven illum.
    img = np.clip(img, 0, 1)
    if not bright:
        img = 1 - img
    return (img * 255).astype(np.uint8), masks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--out", default="../data/raw_synthetic/stage1_train")
    args = ap.parse_args()
    rng = np.random.RandomState(0)
    for k in range(args.n):
        img, masks = make_one(rng)
        d = Path(args.out) / f"synth{k:04d}"
        (d / "images").mkdir(parents=True, exist_ok=True)
        (d / "masks").mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(d / "images" / f"synth{k:04d}.png"), img)
        for j, m in enumerate(masks):
            cv2.imwrite(str(d / "masks" / f"{j:03d}.png"), m)
    print(f"wrote {args.n} synthetic images to {args.out}")


if __name__ == "__main__":
    main()
