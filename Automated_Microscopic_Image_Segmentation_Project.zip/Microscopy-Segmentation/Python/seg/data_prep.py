"""Convert the raw DSB2018 / BBBC038 `stage1_train` folder into a clean dataset.

Raw layout (from the zip):
    data/raw/stage1_train/<id>/images/<id>.png
    data/raw/stage1_train/<id>/masks/*.png        (one binary mask per nucleus)

Output:
    data/processed/images/<id>.png    8-bit grayscale, IMG_SIZE x IMG_SIZE
    data/processed/labels/<id>.png    16-bit instance labels (1..N), 0 = background
    data/processed/splits.json        train / val / test ids (70/15/15)

Usage:
    python -m seg.data_prep --raw ../data/raw/stage1_train
"""
import argparse
import json
import random
from pathlib import Path

import cv2
import numpy as np

from . import config as C
from .preprocess import resize_image, resize_labels, to_gray_uint8


def build_instance_labels(mask_dir: Path, shape):
    lbl = np.zeros(shape, dtype=np.uint16)
    k = 0
    for mp in sorted(mask_dir.glob("*.png")):
        m = cv2.imread(str(mp), cv2.IMREAD_GRAYSCALE)
        if m is None:
            continue
        k += 1
        lbl[(m > 0) & (lbl == 0)] = k   # first mask wins on any overlap
    return lbl


def relabel_sequential(lbl):
    ids = [i for i in np.unique(lbl) if i != 0]
    out = np.zeros_like(lbl)
    for new, old in enumerate(ids, 1):
        out[lbl == old] = new
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=str(C.RAW / "stage1_train"))
    ap.add_argument("--size", type=int, default=C.IMG_SIZE)
    args = ap.parse_args()

    raw = Path(args.raw)
    if not raw.exists():
        raise SystemExit(f"Raw folder not found: {raw}\nSee README step 2 to download the dataset.")
    C.ensure_dirs()
    if not any((p / "images").exists() for p in raw.iterdir() if p.is_dir()):
        nested = raw / "stage1_train"          # zip had an extra top-level folder
        if nested.exists():
            raw = nested
        else:
            raise SystemExit(f"No <id>/images folders inside {raw}. Check the unzip location (README).")

    ids = []
    for d in sorted(p for p in raw.iterdir() if p.is_dir()):
        img_files = list((d / "images").glob("*.png"))
        if not img_files or not (d / "masks").exists():
            continue
        img = cv2.imread(str(img_files[0]), cv2.IMREAD_UNCHANGED)
        gray = to_gray_uint8(img)
        lbl = build_instance_labels(d / "masks", gray.shape)
        gray = resize_image(gray, args.size)
        lbl = relabel_sequential(resize_labels(lbl, args.size))
        cv2.imwrite(str(C.IMG_DIR / f"{d.name}.png"), gray)
        cv2.imwrite(str(C.LBL_DIR / f"{d.name}.png"), lbl)   # uint16 PNG
        ids.append(d.name)

    random.Random(C.SEED).shuffle(ids)
    n = len(ids)
    n_tr, n_va = int(0.70 * n), int(0.15 * n)
    splits = {"train": ids[:n_tr], "val": ids[n_tr:n_tr + n_va], "test": ids[n_tr + n_va:]}
    C.SPLITS.write_text(json.dumps(splits, indent=1))
    print(f"Processed {n} images -> train {len(splits['train'])}, "
          f"val {len(splits['val'])}, test {len(splits['test'])}")


if __name__ == "__main__":
    main()
