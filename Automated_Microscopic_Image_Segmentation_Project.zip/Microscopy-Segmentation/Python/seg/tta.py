"""Flip-based test-time augmentation for segmentation probability maps."""
import cv2
import numpy as np


def predict_tta(predict_fn, image):
    """Average original, horizontal, vertical and 180-degree predictions."""
    predictions = [predict_fn(image)]
    for flip_code in (1, 0, -1):
        flipped = cv2.flip(image, flip_code)
        pred = predict_fn(flipped)
        predictions.append(cv2.flip(pred, flip_code))
    return np.mean(predictions, axis=0, dtype=np.float32)
