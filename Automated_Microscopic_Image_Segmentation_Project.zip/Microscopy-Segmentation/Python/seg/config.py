"""Central paths and settings. Everything is relative to the project root."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
RAW = DATA / "raw"                 # put DSB2018 stage1_train here
PROCESSED = DATA / "processed"     # created by data_prep.py
IMG_DIR = PROCESSED / "images"     # 8-bit grayscale PNG
LBL_DIR = PROCESSED / "labels"     # 16-bit instance label PNG (0 = background)
SPLITS = PROCESSED / "splits.json"
OUT = ROOT / "Results"
MODELS = OUT / "models"

IMG_SIZE = 256
SEED = 42
MIN_OBJECT_AREA = 15               # pixels; smaller blobs are treated as noise


def ensure_dirs():
    for d in (PROCESSED, IMG_DIR, LBL_DIR, OUT, MODELS):
        d.mkdir(parents=True, exist_ok=True)
