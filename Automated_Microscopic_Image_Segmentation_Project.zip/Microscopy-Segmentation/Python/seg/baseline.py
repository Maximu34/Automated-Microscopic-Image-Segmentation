"""Classical baseline: adaptive threshold + marker-controlled watershed.

Run on the test split:
    python -m seg.baseline
Writes 16-bit instance labels to Results/baseline/labels/<id>.png
"""
import argparse
import json
import shutil

import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.feature import peak_local_max
from skimage.filters import threshold_otsu
from skimage.measure import label
from skimage.segmentation import watershed

from . import config as C
from .postprocess import clean_binary, relabel
from .preprocess import normalise_contrast


def foreground_mask(gray, block=51, offset=-2):
    """Adaptive (local-mean) threshold, restricted by a global Otsu gate.

    Polarity is decided automatically: nuclei are assumed to be the *minority*
    class, so bright-on-dark (fluorescence) and dark-on-light (stained)
    images both work.
    """
    g = normalise_contrast(gray)
    otsu = threshold_otsu(g)
    bright_nuclei = (g > otsu).mean() < 0.5
    src = g if bright_nuclei else 255 - g
    local = cv2.adaptiveThreshold(src, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                  cv2.THRESH_BINARY, block, offset) > 0
    gate = src > (otsu if bright_nuclei else 255 - otsu) * 0.8
    mask = local & gate
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))) > 0
    return clean_binary(mask)


def segment(gray, min_distance=5):
    mask = foreground_mask(gray)
    if not mask.any():
        return np.zeros(gray.shape, np.uint16)
    dist = ndi.gaussian_filter(ndi.distance_transform_edt(mask), 1.0)
    peaks = peak_local_max(dist, min_distance=min_distance, labels=label(mask), exclude_border=False)
    markers = np.zeros(gray.shape, np.int32)
    for i, (r, c) in enumerate(peaks, 1):
        markers[r, c] = i
    lbl = watershed(-dist, markers, mask=mask)
    return relabel(lbl.astype(np.uint16))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="test")
    args = ap.parse_args()
    ids = json.loads(C.SPLITS.read_text())[args.split]
    out = C.OUT / "baseline" / "labels"
    gt = C.OUT / "gt"
    out.mkdir(parents=True, exist_ok=True)
    gt.mkdir(parents=True, exist_ok=True)
    for i in ids:
        gray = cv2.imread(str(C.IMG_DIR / f"{i}.png"), cv2.IMREAD_GRAYSCALE)
        cv2.imwrite(str(out / f"{i}.png"), segment(gray))
        shutil.copy(C.LBL_DIR / f"{i}.png", gt / f"{i}.png")
    print(f"Baseline: wrote {len(ids)} label maps to {out}")


if __name__ == "__main__":
    main()
