"""CSV/PDF report generation for measured image and video analysis."""
import csv
from pathlib import Path


def write_csv(path, rows):
    rows=list(rows); path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    if not rows: rows=[{'message':'No cell measurements available'}]
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    return path


def write_pdf(path, title, summary, measurements=None, frame_counts=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with PdfPages(path) as pdf:
        fig=plt.figure(figsize=(11.7,8.3)); fig.text(.08,.9,title,fontsize=20,weight='bold')
        y=.82
        for k,v in summary.items():
            fig.text(.09,y,f'{k.replace("_"," ").title()}: {v}',fontsize=11); y-=.045
        fig.text(.08,.08,'Measurements are pixel-based unless image calibration metadata is supplied.',fontsize=9)
        pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
        if measurements:
            areas=[float(r['area']) for r in measurements if 'area' in r]
            fig,ax=plt.subplots(figsize=(9,5)); ax.hist(areas,bins=30); ax.set_title('Cell area distribution'); ax.set_xlabel('Area (pixels)'); ax.set_ylabel('Cells'); pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
        if frame_counts:
            fig,ax=plt.subplots(figsize=(9,5)); ax.plot([r['time_seconds'] for r in frame_counts],[r['cell_count'] for r in frame_counts]); ax.set_title('Cell count over time'); ax.set_xlabel('Time (seconds)'); ax.set_ylabel('Detected cells'); ax.grid(True,alpha=.25); pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
    return path
