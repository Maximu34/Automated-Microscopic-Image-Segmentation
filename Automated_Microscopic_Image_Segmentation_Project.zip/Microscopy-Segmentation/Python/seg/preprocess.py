"""Pre-processing: grayscale, denoise, contrast normalisation, resize."""
import cv2
import numpy as np


def to_gray_uint8(img):
    """Any DSB2018 image (gray / RGB / RGBA, 8-bit) -> 8-bit grayscale."""
    if img.ndim == 3:
        if img.shape[2] == 4:
            img = img[:, :, :3]
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if img.dtype != np.uint8:
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return img


def normalise_contrast(gray):
    """Gaussian denoise + CLAHE (local contrast equalisation)."""
    den = cv2.GaussianBlur(gray, (3, 3), 0)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(den)


def resize_image(gray, size):
    return cv2.resize(gray, (size, size), interpolation=cv2.INTER_AREA)


def resize_labels(lbl, size):
    # nearest keeps instance ids intact (no blending between neighbours)
    return cv2.resize(lbl, (size, size), interpolation=cv2.INTER_NEAREST)
