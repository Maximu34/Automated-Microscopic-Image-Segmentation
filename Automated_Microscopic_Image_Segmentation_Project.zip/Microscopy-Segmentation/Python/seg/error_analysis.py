"""Per-image difficulty ranking and false-positive/negative object accounting."""
import cv2
from pathlib import Path
from .metrics import all_metrics


def evaluate_image(gt_path, pred_path):
    gt=cv2.imread(str(gt_path),cv2.IMREAD_UNCHANGED); pred=cv2.imread(str(pred_path),cv2.IMREAD_UNCHANGED)
    if gt is None or pred is None: raise FileNotFoundError('Ground-truth or prediction label map is missing')
    if gt.shape != pred.shape: raise ValueError('Ground-truth and prediction dimensions differ')
    return all_metrics(gt,pred)


def rank_difficult_images(gt_dir, prediction_dir, limit=20):
    rows=[]
    for gt_path in sorted(Path(gt_dir).glob('*.png')):
        pred_path=Path(prediction_dir)/gt_path.name
        if not pred_path.exists(): continue
        rows.append({'image':gt_path.stem,**evaluate_image(gt_path,pred_path)})
    return sorted(rows,key=lambda r:(r.get('dice',1),r.get('ap50',1)))[:int(limit)]
