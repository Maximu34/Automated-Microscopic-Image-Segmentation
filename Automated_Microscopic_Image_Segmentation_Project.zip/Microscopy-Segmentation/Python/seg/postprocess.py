"""Turn a binary mask into an instance-label map (split touching cells, drop noise)."""
import numpy as np
from scipy import ndimage as ndi
from skimage.feature import peak_local_max
from skimage.measure import label
from skimage.segmentation import watershed

from . import config as C


def clean_binary(mask, min_area=C.MIN_OBJECT_AREA):
    mask = ndi.binary_fill_holes(mask > 0)
    lab = label(mask)
    sizes = np.bincount(lab.ravel())
    keep = sizes >= min_area
    keep[0] = False
    return keep[lab]


def split_touching(mask, min_distance=4):
    """Distance-transform watershed to separate touching nuclei."""
    if not mask.any():
        return np.zeros(mask.shape, dtype=np.uint16)
    dist = ndi.distance_transform_edt(mask)
    dist = ndi.gaussian_filter(dist, 1.0)
    peaks = peak_local_max(dist, min_distance=min_distance, labels=label(mask), exclude_border=False)
    markers = np.zeros(mask.shape, dtype=np.int32)
    for i, (r, c) in enumerate(peaks, 1):
        markers[r, c] = i
    lbl = watershed(-dist, markers, mask=mask)
    return lbl.astype(np.uint16)


def binary_to_instances(mask, split=True):
    mask = clean_binary(mask)
    if split:
        lbl = split_touching(mask)
    else:
        lbl = label(mask).astype(np.uint16)
    # drop fragments created by watershed that are too small
    for i in np.unique(lbl):
        if i and (lbl == i).sum() < C.MIN_OBJECT_AREA:
            lbl[lbl == i] = 0
    return relabel(lbl)


def relabel(lbl):
    ids = [i for i in np.unique(lbl) if i]
    out = np.zeros_like(lbl, dtype=np.uint16)
    for n, i in enumerate(ids, 1):
        out[lbl == i] = n
    return out
