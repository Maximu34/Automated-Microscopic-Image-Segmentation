"""Pixel and instance metrics with one-to-one object matching."""
import numpy as np
from scipy.optimize import linear_sum_assignment


def pixel_metrics(gt_lbl, pr_lbl):
    g, p = gt_lbl > 0, pr_lbl > 0
    inter = np.logical_and(g, p).sum(); union = np.logical_or(g, p).sum()
    denom = g.sum() + p.sum()
    return {"iou": float(inter/union if union else 1.0),
            "dice": float(2*inter/denom if denom else 1.0),
            "pixel_acc": float((g == p).mean())}


def _iou_matrix(gt, pr):
    gids = np.unique(gt); gids = gids[gids > 0]
    pids = np.unique(pr); pids = pids[pids > 0]
    if not len(gids) or not len(pids): return gids, pids, np.zeros((len(gids),len(pids)),np.float32)
    # Compact relabeling avoids huge bincount arrays for sparse label IDs.
    gi = np.searchsorted(gids, gt); pi = np.searchsorted(pids, pr)
    valid_g = gt > 0; valid_p = pr > 0
    gi[~valid_g] = len(gids); pi[~valid_p] = len(pids)
    joint = np.zeros((len(gids)+1,len(pids)+1),np.int64)
    np.add.at(joint, (gi.ravel(),pi.ravel()), 1)
    inter = joint[:-1,:-1].astype(np.float64)
    ga = joint[:-1,:].sum(1)[:,None]; pa = joint[:,:-1].sum(0)[None,:]
    union = ga + pa - inter
    return gids,pids,np.divide(inter,union,out=np.zeros_like(inter),where=union>0)


def object_metrics(gt_lbl, pr_lbl):
    gids,pids,iou = _iou_matrix(gt_lbl,pr_lbl)
    ng,npred=len(gids),len(pids)
    out={"gt_count":ng,"pred_count":npred}
    aps=[]
    for t in np.linspace(.5,.95,10):
        if iou.size:
            # Maximise the number of threshold-valid one-to-one matches first,
            # then use IoU to break ties. This prevents duplicate detections
            # from inflating TP and avoids a high-IoU edge blocking two matches.
            cost=np.where(iou >= t - 1e-12, -1.0 - iou*1e-3, 1e6)
            rows,cols=linear_sum_assignment(cost)
            tp=int(np.sum(iou[rows,cols] >= t - 1e-12))
        else: tp=0
        fp=npred-tp; fn=ng-tp; den=tp+fp+fn
        score=tp/den if den else 1.0
        aps.append(score)
        if abs(t-.5)<1e-8: out.update(tp=tp,fp=fp,fn=fn,ap50=float(score))
    out["map"]=float(np.mean(aps))
    out["count_acc"]=float(max(0.0,1-abs(ng-npred)/ng)) if ng else float(npred==0)
    return out


def all_metrics(gt_lbl,pr_lbl): return {**pixel_metrics(gt_lbl,pr_lbl),**object_metrics(gt_lbl,pr_lbl)}
