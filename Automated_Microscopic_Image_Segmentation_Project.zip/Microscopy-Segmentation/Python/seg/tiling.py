"""Overlap-tiled U-Net inference with weighted probability blending."""
import cv2
import numpy as np


def _starts(length, tile, overlap):
    if length <= tile: return [0]
    stride=max(1,tile-overlap)
    starts=list(range(0,max(1,length-tile+1),stride))
    last=length-tile
    if starts[-1] != last: starts.append(last)
    return starts


def predict_tiled(predict_fn, gray, tile_size=256, overlap=48, tta=False):
    h,w=gray.shape; tile_size=max(64,int(tile_size)); overlap=min(max(0,int(overlap)),tile_size//2-1)
    acc=np.zeros((h,w),np.float32); weight=np.zeros((h,w),np.float32)
    for y in _starts(h,tile_size,overlap):
        for x in _starts(w,tile_size,overlap):
            patch=gray[y:min(y+tile_size,h),x:min(x+tile_size,w)]; ph,pw=patch.shape
            if ph != tile_size or pw != tile_size:
                patch=cv2.copyMakeBorder(patch,0,tile_size-ph,0,tile_size-pw,cv2.BORDER_REFLECT_101)
            if tta:
                from .tta import predict_tta
                pred=predict_tta(predict_fn,patch)
            else: pred=predict_fn(patch)
            pred=pred[:ph,:pw]
            wy=np.hanning(max(3,ph)).astype(np.float32)[:ph]
            wx=np.hanning(max(3,pw)).astype(np.float32)[:pw]
            win=np.maximum(np.outer(wy,wx),.05)
            acc[y:y+ph,x:x+pw]+=pred*win; weight[y:y+ph,x:x+pw]+=win
    return acc/np.maximum(weight,1e-6)
