"""Train the U-Net.   python -m seg.train --epochs 40 --base 32"""
import argparse
import csv
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from . import config as C
from .dataset import NucleiDataset, load_split
from .unet import DiceBCELoss, UNet


def dice_score(logits, y, thr=0.5):
    p = (torch.sigmoid(logits) > thr).float()
    inter = (p * y).sum(dim=(1, 2, 3))
    den = p.sum(dim=(1, 2, 3)) + y.sum(dim=(1, 2, 3))
    return ((2 * inter + 1e-6) / (den + 1e-6)).mean().item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--base", type=int, default=32, help="channels in first layer (16 for CPU)")
    ap.add_argument("--workers", type=int, default=2)
    args = ap.parse_args()

    C.ensure_dirs()
    torch.manual_seed(C.SEED)
    np.random.seed(C.SEED)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", dev)

    _, ti, tl = load_split("train")
    _, vi, vl = load_split("val")
    tr = DataLoader(NucleiDataset(ti, tl, augment=True), batch_size=args.batch, shuffle=True,
                    num_workers=args.workers, drop_last=len(ti) > args.batch)
    va = DataLoader(NucleiDataset(vi, vl), batch_size=args.batch, num_workers=0)

    model = UNet(base=args.base).to(dev)
    loss_fn = DiceBCELoss()
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=4)
    scaler = torch.amp.GradScaler(enabled=dev == "cuda")

    log = C.OUT / "train_log.csv"
    best = -1.0
    with open(log, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["epoch", "train_loss", "val_loss", "val_dice", "seconds"])
        for ep in range(1, args.epochs + 1):
            t0 = time.time()
            model.train()
            tot = 0.0
            for x, y in tr:
                x, y = x.to(dev), y.to(dev)
                opt.zero_grad()
                with torch.autocast(device_type=dev, enabled=dev == "cuda"):
                    loss = loss_fn(model(x), y)
                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
                tot += loss.item() * len(x)
            model.eval()
            vloss = vdice = 0.0
            with torch.no_grad():
                for x, y in va:
                    x, y = x.to(dev), y.to(dev)
                    out = model(x)
                    vloss += loss_fn(out, y).item() * len(x)
                    vdice += dice_score(out, y) * len(x)
            tl_, vl_, vd = tot / len(tr.dataset), vloss / len(va.dataset), vdice / len(va.dataset)
            sched.step(vl_)
            w.writerow([ep, f"{tl_:.4f}", f"{vl_:.4f}", f"{vd:.4f}", f"{time.time() - t0:.1f}"])
            f.flush()
            tag = ""
            if vd > best:
                best = vd
                torch.save({"model": model.state_dict(), "base": args.base}, C.MODELS / "unet_best.pt")
                tag = "  <- saved"
            print(f"epoch {ep:3d}  train {tl_:.4f}  val {vl_:.4f}  val_dice {vd:.4f}{tag}")
    print(f"best val Dice: {best:.4f}")


if __name__ == "__main__":
    main()
