"""Conservative centroid/IoU-assisted cell tracking for microscopy videos.

Track IDs are provisional identities, not biological lineage claims. Splits/merges
are not asserted; ambiguous associations create new tracks.
"""
import csv
from pathlib import Path
import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment
from .inference import predict_image
from .analysis import measure_cells


def _centroid_distance(a,b):
    return float(np.hypot(a["centroid_x"]-b["centroid_x"],a["centroid_y"]-b["centroid_y"]))


def process_video(video_path, output_dir, threshold=.5, tiling=False, tta=False,
                  max_frames=600, max_distance=45, max_gap=2):
    video_path=Path(video_path); output_dir=Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
    cap=cv2.VideoCapture(str(video_path))
    if not cap.isOpened(): raise ValueError("Could not open the uploaded video")
    fps=cap.get(cv2.CAP_PROP_FPS) or 10.0
    width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer=cv2.VideoWriter(str(output_dir/'tracking.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),fps,(width,height))
    tracks={}; next_id=1; frame_rows=[]; track_rows=[]; frame_no=0
    try:
        while frame_no < int(max_frames):
            ok,frame=cap.read()
            if not ok: break
            gray,prob,labels,mode=predict_image(frame,threshold=threshold,tiling=tiling,tta=tta)
            detections=measure_cells(labels)
            active=[(tid,t) for tid,t in tracks.items() if frame_no-t['last_frame'] <= max_gap+1]
            assigned_dets=set(); assigned_tracks=set()
            if active and detections:
                cost=np.full((len(active),len(detections)),1e6,np.float32)
                for ai,(tid,tr) in enumerate(active):
                    for di,d in enumerate(detections):
                        dist=_centroid_distance(tr['last'],d)
                        if dist <= max_distance*(frame_no-tr['last_frame']): cost[ai,di]=dist
                rr,cc=linear_sum_assignment(cost)
                for ai,di in zip(rr,cc):
                    if cost[ai,di] <= max_distance*(frame_no-active[ai][1]['last_frame']):
                        tid=active[ai][0]; d=detections[di]
                        tracks[tid]['last']=d; tracks[tid]['last_frame']=frame_no
                        tracks[tid]['observations'].append((frame_no,d))
                        d['track_id']=tid; assigned_dets.add(di); assigned_tracks.add(tid)
            for di,d in enumerate(detections):
                if di not in assigned_dets:
                    tid=next_id; next_id+=1; d['track_id']=tid
                    tracks[tid]={'last':d,'last_frame':frame_no,'observations':[(frame_no,d)]}
            for d in detections:
                track_rows.append({'frame':frame_no,'time_seconds':frame_no/fps,**d})
            frame_rows.append({'frame':frame_no,'time_seconds':frame_no/fps,'cell_count':len(detections),'inference_mode':mode})
            vis=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
            colors={int(d['cell_id']):((37*int(d['track_id']))%255,(97*int(d['track_id']))%255,(173*int(d['track_id']))%255) for d in detections}
            for d in detections:
                x,y=int(d['centroid_x']),int(d['centroid_y']); col=colors[d['cell_id']]
                tid=d['track_id']; history=tracks[tid]['observations']
                path=np.array([[int(o['centroid_x']),int(o['centroid_y'])] for _,o in history],dtype=np.int32)
                if len(path)>1: cv2.polylines(vis,[path.reshape(-1,1,2)],False,col,1,cv2.LINE_AA)
                cv2.circle(vis,(x,y),4,col,-1); cv2.putText(vis,f"ID {tid}",(x+5,y-5),cv2.FONT_HERSHEY_SIMPLEX,.45,col,1,cv2.LINE_AA)
            cv2.putText(vis,f"Frame {frame_no} | cells {len(detections)}",(12,26),cv2.FONT_HERSHEY_SIMPLEX,.7,(0,255,255),2)
            writer.write(vis); frame_no+=1
    finally:
        cap.release(); writer.release()
    if frame_no==0: raise ValueError("The uploaded video contains no readable frames")
    def save_csv(path,rows):
        keys=list(dict.fromkeys(k for r in rows for k in r))
        with open(path,'w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
    save_csv(output_dir/'frame_counts.csv',frame_rows); save_csv(output_dir/'tracks.csv',track_rows)
    track_summary=[]
    for tid,tr in tracks.items():
        observations=tr['observations']; first=observations[0][1]; last=observations[-1][1]
        start_area=float(first['area']); end_area=float(last['area'])
        track_summary.append({'track_id':tid,'first_frame':observations[0][0],'last_frame':observations[-1][0],
            'observations':len(observations),'displacement_pixels':_centroid_distance(first,last),
            'start_area_pixels':start_area,'end_area_pixels':end_area,'area_change_pixels':end_area-start_area,
            'area_change_percent':((end_area-start_area)/start_area*100.0 if start_area else 0.0)})
    save_csv(output_dir/'track_summary.csv',track_summary)
    summary={'frames_processed':frame_no,'fps':fps,'duration_seconds':frame_no/fps,
             'tracks_created':len(tracks),'mean_cell_count':float(np.mean([r['cell_count'] for r in frame_rows])),
             'max_cell_count':max(r['cell_count'] for r in frame_rows),
             'limitations':'Centroid-based association can switch identities during close contacts, occlusion, division, merging or rapid motion. Track IDs are not lineage labels.'}
    return summary
