"""Compare baseline vs U-Net and cross-check the Java tool against Python.

Needs: Results/{gt,baseline/labels,unet/labels} (from baseline.py / predict.py)
       Results/{baseline,unet}/metrics.csv + features.csv (from the Java tool)

    python -m seg.compare
Produces Results/comparison.csv, comparison.png, qualitative.png, training_curve.png
"""
import json

import cv2
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from . import config as C
from .metrics import all_metrics

METHODS = {"baseline": "Classical (threshold+watershed)", "unet": "U-Net"}
KEYS = ["iou", "dice", "pixel_acc", "count_acc", "ap50", "map"]


def python_metrics(method):
    rows = []
    for p in sorted((C.OUT / "gt").glob("*.png")):
        gt = cv2.imread(str(p), cv2.IMREAD_UNCHANGED)
        pr = cv2.imread(str(C.OUT / method / "labels" / p.name), cv2.IMREAD_UNCHANGED)
        rows.append({"image": p.stem, **all_metrics(gt, pr)})
    return pd.DataFrame(rows)


def main():
    summary, per_img = [], {}
    for m, name in METHODS.items():
        if not (C.OUT / m / "labels").exists():
            print(f"skip {m}: no predictions yet")
            continue
        df = python_metrics(m)
        per_img[m] = df
        df.to_csv(C.OUT / m / "metrics_python.csv", index=False)
        row = {"method": name, **{k: df[k].mean() for k in KEYS}}
        jcsv = C.OUT / m / "metrics.csv"
        if jcsv.exists():
            jd = pd.read_csv(jcsv).set_index("image").loc[df["image"]]
            diff = max(abs(jd[k].values - df[k].values).max() for k in ["iou", "dice", "ap50", "map"])
            row["java_vs_python_maxdiff"] = diff
            print(f"{m}: Java vs Python max metric difference = {diff:.2e}")
        summary.append(row)
    if not summary:
        raise SystemExit("Nothing to compare. Run baseline.py and predict.py first.")

    s = pd.DataFrame(summary)
    s.to_csv(C.OUT / "comparison.csv", index=False)
    print(s.round(4).to_string(index=False))

    # bar chart
    fig, ax = plt.subplots(figsize=(9, 4))
    w = 0.8 / len(s)
    for j, (_, r) in enumerate(s.iterrows()):
        ax.bar(np.arange(len(KEYS)) + j * w, [r[k] for k in KEYS], w, label=r["method"])
    ax.set_xticks(np.arange(len(KEYS)) + w * (len(s) - 1) / 2)
    ax.set_xticklabels(["IoU", "Dice", "Pixel acc", "Count acc", "AP@0.5", "mAP@0.5:0.95"])
    ax.set_ylim(0, 1)
    ax.legend()
    ax.set_title("Test-set comparison")
    fig.tight_layout()
    fig.savefig(C.OUT / "comparison.png", dpi=150)
    plt.close(fig)

    # qualitative panels: 4 test images, GT vs each method
    ids = [p.stem for p in sorted((C.OUT / "gt").glob("*.png"))][:4]
    cols = 2 + len(per_img)
    fig, axs = plt.subplots(len(ids), cols, figsize=(3 * cols, 3 * len(ids)), squeeze=False)
    for r, i in enumerate(ids):
        img = cv2.imread(str(C.IMG_DIR / f"{i}.png"), cv2.IMREAD_GRAYSCALE)
        panels = [("Image", img), ("Ground truth", cv2.imread(str(C.OUT / "gt" / f"{i}.png"), -1))]
        panels += [(METHODS[m], cv2.imread(str(C.OUT / m / "labels" / f"{i}.png"), -1)) for m in per_img]
        for c, (t, a) in enumerate(panels):
            axs[r, c].imshow(a, cmap="gray" if c == 0 else "nipy_spectral", interpolation="nearest")
            axs[r, c].axis("off")
            if r == 0:
                axs[r, c].set_title(t, fontsize=9)
    fig.tight_layout()
    fig.savefig(C.OUT / "qualitative.png", dpi=130)
    plt.close(fig)

    log = C.OUT / "train_log.csv"
    if log.exists():
        d = pd.read_csv(log)
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.2))
        ax[0].plot(d.epoch, d.train_loss, label="train")
        ax[0].plot(d.epoch, d.val_loss, label="val")
        ax[0].set_title("Dice+BCE loss")
        ax[0].legend()
        ax[1].plot(d.epoch, d.val_dice)
        ax[1].set_title("Validation Dice")
        fig.tight_layout()
        fig.savefig(C.OUT / "training_curve.png", dpi=150)
        plt.close(fig)
    print("Saved comparison.csv, comparison.png, qualitative.png, training_curve.png in Results/")


if __name__ == "__main__":
    main()
