"""Measurements and evaluation helpers for instance-label images."""
import numpy as np
import cv2
from skimage.measure import regionprops
from .metrics import all_metrics


def measure_cells(labels):
    rows=[]
    for r in regionprops(labels.astype(np.int32)):
        cy,cx=r.centroid
        rows.append({"cell_id":int(r.label),"area":float(r.area),"perimeter":float(r.perimeter),
                     "centroid_x":float(cx),"centroid_y":float(cy),
                     "eccentricity":float(r.eccentricity),"solidity":float(r.solidity)})
    return rows


def compare_labels(gt, pred):
    return all_metrics(gt,pred)


def confidence_overlay(gray, probability):
    # Uncertainty is highest near p=0.5 and lowest near confident 0/1 values.
    uncertainty=1.0-np.abs(2.0*np.clip(probability,0,1)-1.0)
    heat=(uncertainty*255).astype(np.uint8)
    color=cv2.applyColorMap(heat,cv2.COLORMAP_TURBO)
    base=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    return cv2.addWeighted(base,.52,color,.48,0)
