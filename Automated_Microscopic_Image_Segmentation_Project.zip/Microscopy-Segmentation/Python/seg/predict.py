"""Run the trained U-Net on a split and save instance label maps.

    python -m seg.predict --split test
Writes Results/unet/labels/<id>.png (16-bit) and Results/gt/<id>.png (ground truth copy,
so the Java tool can compare two folders with matching filenames).
"""
import argparse
import json
import shutil

import cv2
import numpy as np
import torch

from . import config as C
from .postprocess import binary_to_instances
from .preprocess import normalise_contrast
from .unet import UNet


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="test")
    ap.add_argument("--weights", default=str(C.MODELS / "unet_best.pt"))
    ap.add_argument("--thr", type=float, default=0.5)
    args = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    ck = torch.load(args.weights, map_location=dev)
    model = UNet(base=ck["base"]).to(dev)
    model.load_state_dict(ck["model"])
    model.eval()

    ids = json.loads(C.SPLITS.read_text())[args.split]
    out = C.OUT / "unet" / "labels"
    gt = C.OUT / "gt"
    out.mkdir(parents=True, exist_ok=True)
    gt.mkdir(parents=True, exist_ok=True)
    with torch.no_grad():
        for i in ids:
            g = cv2.imread(str(C.IMG_DIR / f"{i}.png"), cv2.IMREAD_GRAYSCALE)
            x = torch.from_numpy(normalise_contrast(g).astype(np.float32) / 255.0)[None, None].to(dev)
            prob = torch.sigmoid(model(x))[0, 0].cpu().numpy()
            lbl = binary_to_instances(prob > args.thr)
            cv2.imwrite(str(out / f"{i}.png"), lbl)
            shutil.copy(C.LBL_DIR / f"{i}.png", gt / f"{i}.png")
    print(f"U-Net: wrote {len(ids)} label maps to {out}")


if __name__ == "__main__":
    main()
