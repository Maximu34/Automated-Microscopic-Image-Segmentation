"""Reusable inference helpers for the existing trained U-Net checkpoint."""
from __future__ import annotations
import sys
from pathlib import Path
import cv2
import numpy as np
import torch

from . import config as C
from .postprocess import binary_to_instances
from .preprocess import normalise_contrast
from .unet import UNet

_MODEL_CACHE = {}


def load_model(weights=None, device=None):
    weights = Path(weights or C.MODELS / "unet_best.pt").resolve()
    if not weights.is_file():
        raise FileNotFoundError(f"Trained U-Net weights not found: {weights}")
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    key = (str(weights), device, weights.stat().st_mtime_ns)
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    try:
        ckpt = torch.load(str(weights), map_location=device, weights_only=False)
    except TypeError:
        ckpt = torch.load(str(weights), map_location=device)
    model = UNet(base=int(ckpt.get("base", 32))).to(device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    _MODEL_CACHE.clear()
    _MODEL_CACHE[key] = model
    return model


def _predict_tensor(model, gray, device):
    norm = normalise_contrast(gray).astype(np.float32) / 255.0
    h, w = norm.shape
    ph, pw = (-h) % 16, (-w) % 16
    if ph or pw:
        border = cv2.BORDER_REFLECT_101 if min(h, w) > 1 else cv2.BORDER_REPLICATE
        norm = cv2.copyMakeBorder(norm, 0, ph, 0, pw, border)
    x = torch.from_numpy(norm)[None, None].to(device)
    with torch.inference_mode():
        p = torch.sigmoid(model(x))[0, 0].detach().cpu().numpy()[:h, :w]
    return p.astype(np.float32)


def tiled_probability(model, gray, device, tile_size=256, overlap=48, tta=False):
    from .tiling import predict_tiled
    predict_fn=lambda patch: _predict_tensor(model,patch,device)
    return predict_tiled(predict_fn,gray,tile_size=tile_size,overlap=overlap,tta=tta)


def predict_image(image, weights=None, threshold=0.5, tiling=False, tta=False, tile_size=256, overlap=48):
    if image is None or image.size == 0:
        raise ValueError("The uploaded image is empty or unreadable")
    if image.ndim == 3:
        if image.shape[2] == 4: image = image[:, :, :3]
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()
    if gray.dtype != np.uint8:
        gray = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = load_model(weights, device)
    if tiling or gray.shape[0] > 512 or gray.shape[1] > 512:
        prob = tiled_probability(model, gray, device, tile_size, overlap, tta)
        mode = "tiled" + (" + TTA" if tta else "")
    else:
        predict_fn=lambda patch: _predict_tensor(model,patch,device)
        if tta:
            from .tta import predict_tta
            prob=predict_tta(predict_fn,gray)
        else:
            prob=predict_fn(gray)
        mode = "standard" + (" + TTA" if tta else "")
    labels = binary_to_instances(prob >= float(threshold))
    return gray, prob, labels, mode
