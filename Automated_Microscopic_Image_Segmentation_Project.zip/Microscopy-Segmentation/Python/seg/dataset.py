"""In-memory dataset with augmentation (flip, rot90, elastic deformation, brightness)."""
import json

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

from . import config as C
from .preprocess import normalise_contrast


def load_split(split):
    ids = json.loads(C.SPLITS.read_text())[split]
    imgs = [normalise_contrast(cv2.imread(str(C.IMG_DIR / f"{i}.png"), cv2.IMREAD_GRAYSCALE)) for i in ids]
    lbls = [cv2.imread(str(C.LBL_DIR / f"{i}.png"), cv2.IMREAD_UNCHANGED) for i in ids]
    return ids, imgs, lbls


def elastic(img, mask, alpha=30, sigma=4, rng=None):
    rng = rng or np.random
    h, w = img.shape
    dx = cv2.GaussianBlur((rng.rand(h, w) * 2 - 1).astype(np.float32), (0, 0), sigma) * alpha
    dy = cv2.GaussianBlur((rng.rand(h, w) * 2 - 1).astype(np.float32), (0, 0), sigma) * alpha
    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    mx, my = gx + dx, gy + dy
    img = cv2.remap(img, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    mask = cv2.remap(mask, mx, my, cv2.INTER_NEAREST, borderMode=cv2.BORDER_REFLECT)
    return img, mask


class NucleiDataset(Dataset):
    def __init__(self, imgs, lbls, augment=False):
        self.imgs, self.lbls, self.augment = imgs, lbls, augment

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, i):
        img = self.imgs[i]
        mask = (self.lbls[i] > 0).astype(np.uint8)
        if self.augment:
            if np.random.rand() < 0.5:
                img, mask = img[:, ::-1], mask[:, ::-1]
            if np.random.rand() < 0.5:
                img, mask = img[::-1], mask[::-1]
            k = np.random.randint(4)
            img, mask = np.rot90(img, k), np.rot90(mask, k)
            img, mask = np.ascontiguousarray(img), np.ascontiguousarray(mask)
            if np.random.rand() < 0.4:
                img, mask = elastic(img, mask)
            img = np.clip(img.astype(np.float32) * np.random.uniform(0.8, 1.2)
                          + np.random.uniform(-15, 15), 0, 255)
        x = torch.from_numpy(np.asarray(img, dtype=np.float32) / 255.0)[None]
        y = torch.from_numpy(mask.astype(np.float32))[None]
        return x, y
