"""Measured inference ablation on the held-out raw DSB2018 test split.

Compares 256px resize inference, resize+TTA, native-resolution tiled inference,
and native-resolution tiled+TTA. It reuses the existing checkpoint and never trains.
"""
import argparse, csv, json, time, random
from pathlib import Path
import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from . import config as C
from .inference import load_model, _predict_tensor
from .tta import predict_tta
from .tiling import predict_tiled
from .postprocess import binary_to_instances
from .metrics import all_metrics


def raw_paths(image_id):
    root=C.RAW/'stage1_train'/image_id
    images=list((root/'images').glob('*.png'))
    masks=sorted((root/'masks').glob('*.png'))
    if not images or not masks: raise FileNotFoundError(f'Raw image/masks missing for {image_id}')
    return images[0],masks


def load_gt(mask_paths):
    first=cv2.imread(str(mask_paths[0]),cv2.IMREAD_GRAYSCALE)
    if first is None: raise ValueError('Could not read ground-truth mask')
    labels=np.zeros(first.shape,np.uint16)
    for idx,path in enumerate(mask_paths,1):
        mask=cv2.imread(str(path),cv2.IMREAD_GRAYSCALE)
        if mask is None: continue
        labels[(mask>0)&(labels==0)]=idx
    return labels


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--split',default='test'); ap.add_argument('--tile-size',type=int,default=256); ap.add_argument('--overlap',type=int,default=48); ap.add_argument('--max-images',type=int,default=0,help='Optional deterministic random subset size; 0 evaluates the full split'); ap.add_argument('--seed',type=int,default=42)
    args=ap.parse_args(); ids=json.loads(C.SPLITS.read_text())[args.split]
    if args.max_images and args.max_images < len(ids): ids=sorted(random.Random(args.seed).sample(ids,args.max_images))
    device='cuda' if __import__('torch').cuda.is_available() else 'cpu'; model=load_model(device=device)
    predict_fn=lambda a:_predict_tensor(model,a,device)
    modes=['resize_256','resize_256_tta','native_tiled','native_tiled_tta']; rows=[]
    for index,image_id in enumerate(ids,1):
        image_path,mask_paths=raw_paths(image_id); gray=cv2.imread(str(image_path),cv2.IMREAD_GRAYSCALE)
        if gray is None: raise ValueError(f'Could not read {image_path}')
        gt=load_gt(mask_paths); h,w=gray.shape
        if gt.shape != gray.shape: raise ValueError(f'Image/mask shape mismatch for {image_id}')
        small=cv2.resize(gray,(C.IMG_SIZE,C.IMG_SIZE),interpolation=cv2.INTER_AREA)
        for mode in modes:
            started=time.perf_counter()
            if mode.startswith('resize'):
                prob=predict_tta(predict_fn,small) if mode.endswith('_tta') else predict_fn(small)
                prob=cv2.resize(prob,(w,h),interpolation=cv2.INTER_LINEAR)
            else:
                prob=predict_tiled(predict_fn,gray,args.tile_size,args.overlap,tta=mode.endswith('_tta'))
            pred=binary_to_instances(prob>=.5)
            metrics=all_metrics(gt,pred)
            rows.append({'image':image_id,'mode':mode,'height':h,'width':w,'runtime_seconds':time.perf_counter()-started,**metrics})
        print(f'[{index}/{len(ids)}] {image_id}',flush=True)
    out=C.OUT/'ablation'; out.mkdir(parents=True,exist_ok=True)
    with (out/'inference_ablation.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    keys=['iou','dice','pixel_acc','count_acc','ap50','map','runtime_seconds']
    summary=[]
    for mode in modes:
        subset=[r for r in rows if r['mode']==mode]
        summary.append({'mode':mode,'images':len(subset),**{k:float(np.mean([r[k] for r in subset])) for k in keys}})
    (out/'summary.json').write_text(json.dumps({'split':args.split,'images':len(ids),'image_ids':ids,'subset_seed':args.seed if args.max_images else None,'tile_size':args.tile_size,'overlap':args.overlap,'results':summary},indent=2))
    fig,ax=plt.subplots(figsize=(10,5)); x=np.arange(len(modes)); width=.12
    for i,k in enumerate(['dice','iou','ap50','map']): ax.bar(x+(i-1.5)*width,[r[k] for r in summary],width,label=k)
    ax.set_xticks(x);ax.set_xticklabels(modes,rotation=15,ha='right');ax.set_ylim(0,1);ax.set_ylabel('Mean test score');ax.set_title(f'Inference strategy ablation · held-out test sample (n={len(ids)})');ax.legend();fig.tight_layout();fig.savefig(out/'inference_ablation.png',dpi=160);plt.close(fig)
    print(json.dumps(summary,indent=2));print(f'Saved {out}')

if __name__=='__main__': main()
