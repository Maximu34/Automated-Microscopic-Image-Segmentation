"""Build Results/demo_outputs/ from SYNTHETIC data so the dashboard has something to show.
Not real results. Real runs write to Results/ and take priority automatically.

    python build_demo.py
"""
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def run(*a, cwd=ROOT / "Python"):
    print(">", " ".join(map(str, a)))
    subprocess.run([str(x) for x in a], cwd=cwd, check=True)


def main():
    for d in ("data/processed", "Results", "data/raw_synthetic"):
        shutil.rmtree(ROOT / d, ignore_errors=True)
    run(PY, "make_synthetic.py", "--n", "150", "--out", "../data/raw_synthetic/stage1_train")
    run(PY, "-m", "seg.data_prep", "--raw", "../data/raw_synthetic/stage1_train")
    run(PY, "-m", "seg.baseline")
    run(PY, "-m", "seg.train", "--epochs", "30", "--base", "16", "--batch", "8", "--workers", "0")
    run(PY, "-m", "seg.predict")
    run(PY, str(ROOT / "run_all.py"), "--java-only", cwd=ROOT)
    run(PY, "-m", "seg.compare")

    demo = ROOT / "Results" / "demo_outputs"
    shutil.rmtree(demo, ignore_errors=True)
    shutil.copytree(ROOT / "Results", demo, ignore=shutil.ignore_patterns("models"))
    (demo / "images").mkdir()
    for p in (demo / "gt").glob("*.png"):
        shutil.copy(ROOT / "data" / "processed" / "images" / p.name, demo / "images" / p.name)
    shutil.copy(ROOT / "data" / "processed" / "splits.json", demo / "splits.json")
    for d in ("data/processed", "Results", "data/raw_synthetic"):
        shutil.rmtree(ROOT / d, ignore_errors=True)
    (ROOT / "Results").mkdir()
    print("Results/demo_outputs/ ready")


if __name__ == "__main__":
    main()
