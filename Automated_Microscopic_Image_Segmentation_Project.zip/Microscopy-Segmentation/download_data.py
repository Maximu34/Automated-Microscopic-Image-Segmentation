"""Download + unzip the DSB2018 / BBBC038 stage1_train dataset (82.9 MB, CC0).

    python download_data.py

If this fails (college Wi-Fi / firewall), download it by hand in your browser:
    https://data.broadinstitute.org/bbbc/BBBC038/stage1_train.zip
and unzip it into  data/raw/stage1_train/  so that it contains many folders like
    data/raw/stage1_train/0a7d30b2.../images/0a7d30b2....png
"""
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

URL = "https://data.broadinstitute.org/bbbc/BBBC038/stage1_train.zip"
ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw"
DEST = RAW / "stage1_train"


def have_data():
    return DEST.exists() and any(p.is_dir() and (p / "images").exists() for p in DEST.iterdir())


def main():
    if have_data():
        print("Dataset already present:", DEST)
        return
    RAW.mkdir(parents=True, exist_ok=True)
    zpath = RAW / "stage1_train.zip"
    print("Downloading", URL)

    def hook(b, bs, total):
        if total > 0:
            done = min(b * bs, total)
            sys.stdout.write(f"\r  {done / 1e6:6.1f} / {total / 1e6:.1f} MB")
            sys.stdout.flush()

    try:
        urllib.request.urlretrieve(URL, zpath, hook)
    except Exception as e:
        raise SystemExit(f"\nDownload failed: {e}\nDownload it manually: {URL}\nThen unzip into {DEST}")
    print("\nUnzipping ...")
    DEST.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(DEST)
    # some zips contain one extra top-level folder: flatten it
    inner = DEST / "stage1_train"
    if inner.exists() and not any((p / "images").exists() for p in DEST.iterdir() if p.is_dir() and p != inner):
        for p in inner.iterdir():
            shutil.move(str(p), str(DEST / p.name))
        inner.rmdir()
    zpath.unlink(missing_ok=True)
    n = sum(1 for p in DEST.iterdir() if p.is_dir() and (p / "images").exists())
    print(f"Done: {n} images in {DEST}")
    if n < 600:
        print("WARNING: expected 670 image folders. Check the unzip location.")


if __name__ == "__main__":
    main()
