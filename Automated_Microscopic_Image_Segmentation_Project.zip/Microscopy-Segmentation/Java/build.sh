#!/usr/bin/env bash
# Build without Maven: needs only a JDK (17+).   ./build.sh
set -e
cd "$(dirname "$0")"
rm -rf out && mkdir -p out
javac -d out $(find src/main/java -name "*.java")
echo "Built -> Java/out   (run: java -cp Java/out com.jainth.seg.Main --help)"
