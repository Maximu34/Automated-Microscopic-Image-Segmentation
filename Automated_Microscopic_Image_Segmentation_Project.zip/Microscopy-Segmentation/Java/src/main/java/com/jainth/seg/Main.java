package com.jainth.seg;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Feature extraction + evaluation CLI.
 *
 *   java -cp out com.jainth.seg.Main --pred outputs/unet/labels --gt outputs/gt --out outputs/unet
 *
 * Writes <out>/features.csv (one row per detected object) and
 *        <out>/metrics.csv  (one row per image) and prints a summary.
 * --gt is optional: without it only features.csv is produced.
 */
public final class Main {
    public static void main(String[] args) throws IOException {
        String pred = null, gt = null, out = null;
        for (int i = 0; i < args.length - 1; i += 2) {
            switch (args[i]) {
                case "--pred": pred = args[i + 1]; break;
                case "--gt": gt = args[i + 1]; break;
                case "--out": out = args[i + 1]; break;
                default: usage();
            }
        }
        if (pred == null || out == null) usage();
        File[] files = new File(pred).listFiles((d, n) -> n.toLowerCase().endsWith(".png"));
        if (files == null || files.length == 0) throw new IOException("No PNG files in " + pred);
        Arrays.sort(files);
        new File(out).mkdirs();

        double sIou = 0, sDice = 0, sAcc = 0, sCnt = 0, sAp = 0, sMap = 0;
        int n = 0;
        try (PrintWriter fw = new PrintWriter(new File(out, "features.csv"), "UTF-8");
             PrintWriter mw = gt != null ? new PrintWriter(new File(out, "metrics.csv"), "UTF-8") : null) {
            fw.println("image,label,area,perimeter,centroid_x,centroid_y,eccentricity,solidity");
            if (mw != null)
                mw.println("image,iou,dice,pixel_acc,gt_count,pred_count,count_acc,tp,fp,fn,ap50,map");
            for (File f : files) {
                String id = f.getName().replaceFirst("\\.png$", "");
                LabelImage pr = LabelImage.read(f);
                List<Features> feats = Features.extract(pr);
                for (Features ft : feats)
                    fw.printf(Locale.ROOT, "%s,%d,%.0f,%.4f,%.3f,%.3f,%.5f,%.5f%n",
                            id, ft.label, ft.area, ft.perimeter, ft.cx, ft.cy, ft.eccentricity, ft.solidity);
                if (mw != null) {
                    File g = new File(gt, f.getName());
                    if (!g.exists()) { System.err.println("No ground truth for " + id + ", skipped"); continue; }
                    Metrics m = Metrics.compute(LabelImage.read(g), pr);
                    mw.printf(Locale.ROOT, "%s,%.6f,%.6f,%.6f,%d,%d,%.6f,%d,%d,%d,%.6f,%.6f%n",
                            id, m.iou, m.dice, m.pixelAcc, m.gtCount, m.predCount, m.countAcc,
                            m.tp, m.fp, m.fn, m.ap50, m.map);
                    sIou += m.iou; sDice += m.dice; sAcc += m.pixelAcc;
                    sCnt += m.countAcc; sAp += m.ap50; sMap += m.map; n++;
                }
            }
        }
        System.out.println("Processed " + files.length + " images -> " + out + "/features.csv");
        if (n > 0)
            System.out.printf(Locale.ROOT,
                    "Mean over %d images: IoU %.4f | Dice %.4f | PixelAcc %.4f | CountAcc %.4f | AP@0.5 %.4f | mAP %.4f%n",
                    n, sIou / n, sDice / n, sAcc / n, sCnt / n, sAp / n, sMap / n);
    }

    private static void usage() {
        System.err.println("Usage: Main --pred <label-dir> --out <dir> [--gt <gt-label-dir>]");
        System.exit(2);
    }
}
