package com.jainth.seg;

/** Two-pass connected-component labelling with union-find (8-connectivity). */
public final class ConnectedComponents {
    private ConnectedComponents() {}

    public static LabelImage label(int[] bin, int w, int h) {
        int[] lab = new int[w * h];
        int[] parent = new int[w * h / 2 + 2];
        int next = 1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (bin[y * w + x] == 0) continue;
                int[] nb = new int[4];
                int n = 0;
                if (x > 0 && lab[y * w + x - 1] > 0) nb[n++] = lab[y * w + x - 1];
                if (y > 0) {
                    if (lab[(y - 1) * w + x] > 0) nb[n++] = lab[(y - 1) * w + x];
                    if (x > 0 && lab[(y - 1) * w + x - 1] > 0) nb[n++] = lab[(y - 1) * w + x - 1];
                    if (x < w - 1 && lab[(y - 1) * w + x + 1] > 0) nb[n++] = lab[(y - 1) * w + x + 1];
                }
                if (n == 0) {
                    if (next >= parent.length) parent = java.util.Arrays.copyOf(parent, parent.length * 2);
                    parent[next] = next;
                    lab[y * w + x] = next++;
                } else {
                    int m = nb[0];
                    for (int i = 1; i < n; i++) m = Math.min(m, nb[i]);
                    lab[y * w + x] = m;
                    for (int i = 0; i < n; i++) union(parent, m, nb[i]);
                }
            }
        }
        // second pass: resolve to sequential ids
        int[] remap = new int[next];
        int count = 0;
        for (int i = 0; i < lab.length; i++) {
            if (lab[i] == 0) continue;
            int root = find(parent, lab[i]);
            if (remap[root] == 0) remap[root] = ++count;
            lab[i] = remap[root];
        }
        return new LabelImage(w, h, lab, count);
    }

    private static int find(int[] p, int a) {
        while (p[a] != a) { p[a] = p[p[a]]; a = p[a]; }
        return a;
    }

    private static void union(int[] p, int a, int b) {
        int ra = find(p, a), rb = find(p, b);
        if (ra != rb) { if (ra < rb) p[rb] = ra; else p[ra] = rb; }
    }
}
