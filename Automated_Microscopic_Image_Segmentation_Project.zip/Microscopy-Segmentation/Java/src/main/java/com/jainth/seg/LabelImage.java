package com.jainth.seg;

import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/** Reads a mask PNG into an int[h][w] instance-label array.
 *  16-bit PNG  -> already an instance label map (0 = background).
 *  8-bit PNG   -> binary mask (any value > 0 is foreground); labelled by connected components. */
public final class LabelImage {
    public final int width, height;
    public final int[] labels;      // row-major, 0 = background
    public final int count;         // number of objects

    public LabelImage(int width, int height, int[] labels, int count) {
        this.width = width; this.height = height; this.labels = labels; this.count = count;
    }

    public static LabelImage read(File f) throws IOException {
        BufferedImage img = ImageIO.read(f);
        if (img == null) throw new IOException("Cannot read image: " + f);
        int w = img.getWidth(), h = img.getHeight();
        Raster r = img.getRaster();
        int[] v = new int[w * h];
        boolean is16 = r.getDataBuffer().getDataType() == java.awt.image.DataBuffer.TYPE_USHORT
                || img.getColorModel().getPixelSize() == 16;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                v[y * w + x] = r.getSample(x, y, 0);
        if (is16) {
            int max = 0;
            for (int a : v) max = Math.max(max, a);
            return new LabelImage(w, h, v, countDistinct(v, max));
        }
        int[] bin = new int[w * h];
        for (int i = 0; i < v.length; i++) bin[i] = v[i] > 0 ? 1 : 0;
        return ConnectedComponents.label(bin, w, h);
    }

    private static int countDistinct(int[] v, int max) {
        boolean[] seen = new boolean[max + 1];
        int n = 0;
        for (int a : v) if (a > 0 && !seen[a]) { seen[a] = true; n++; }
        return n;
    }
}
