package com.jainth.seg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Morphological descriptors per object: area, perimeter, centroid, eccentricity, solidity.
 *  Definitions follow scikit-image's regionprops so results can be cross-checked with Python. */
public final class Features {
    public final int label;
    public double area, perimeter, cx, cy, eccentricity, solidity;

    private Features(int label) { this.label = label; }

    public static List<Features> extract(LabelImage im) {
        int w = im.width, h = im.height, n = im.count;
        int maxLabel = 0;
        for (int v : im.labels) maxLabel = Math.max(maxLabel, v);

        // bounding boxes
        int[] x0 = new int[maxLabel + 1], x1 = new int[maxLabel + 1];
        int[] y0 = new int[maxLabel + 1], y1 = new int[maxLabel + 1];
        Arrays.fill(x0, Integer.MAX_VALUE); Arrays.fill(y0, Integer.MAX_VALUE);
        Arrays.fill(x1, -1); Arrays.fill(y1, -1);
        long[] cnt = new long[maxLabel + 1];
        double[] sx = new double[maxLabel + 1], sy = new double[maxLabel + 1];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                int l = im.labels[y * w + x];
                if (l == 0) continue;
                cnt[l]++; sx[l] += x; sy[l] += y;
                x0[l] = Math.min(x0[l], x); x1[l] = Math.max(x1[l], x);
                y0[l] = Math.min(y0[l], y); y1[l] = Math.max(y1[l], y);
            }

        List<Features> out = new ArrayList<>();
        for (int l = 1; l <= maxLabel; l++) {
            if (cnt[l] == 0) continue;
            Features f = new Features(l);
            f.area = cnt[l];
            f.cx = sx[l] / cnt[l];
            f.cy = sy[l] / cnt[l];
            // crop to bounding box (pad 1 so border pixels have a background neighbour)
            int bw = x1[l] - x0[l] + 1, bh = y1[l] - y0[l] + 1;
            boolean[][] m = new boolean[bh + 2][bw + 2];
            for (int y = y0[l]; y <= y1[l]; y++)
                for (int x = x0[l]; x <= x1[l]; x++)
                    if (im.labels[y * w + x] == l) m[y - y0[l] + 1][x - x0[l] + 1] = true;
            f.perimeter = perimeter(m);
            f.eccentricity = eccentricity(m, f.area);
            f.solidity = solidity(m, f.area);
            out.add(f);
        }
        return out;
    }

    /** Same estimator as skimage.measure.perimeter (4-neighbour border + weighted 3x3 code). */
    static double perimeter(boolean[][] m) {
        int h = m.length, w = m[0].length;
        boolean[][] border = new boolean[h][w];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                if (!m[y][x]) continue;
                boolean inner = y > 0 && y < h - 1 && x > 0 && x < w - 1
                        && m[y - 1][x] && m[y + 1][x] && m[y][x - 1] && m[y][x + 1];
                border[y][x] = !inner;
            }
        int[][] k = {{10, 2, 10}, {2, 1, 2}, {10, 2, 10}};
        double s2 = Math.sqrt(2), mid = (1 + s2) / 2;
        double total = 0;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                if (!border[y][x]) continue;
                int code = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++) {
                        int yy = y + dy, xx = x + dx;
                        if (yy >= 0 && yy < h && xx >= 0 && xx < w && border[yy][xx])
                            code += k[dy + 1][dx + 1];
                    }
                switch (code) {
                    case 5: case 7: case 15: case 17: case 25: case 27: total += 1; break;
                    case 21: case 33: total += s2; break;
                    case 13: case 23: total += mid; break;
                    default: break;
                }
            }
        return total;
    }

    /** sqrt(1 - l2/l1) from eigenvalues of the second central moments. */
    static double eccentricity(boolean[][] m, double area) {
        double mx = 0, my = 0;
        for (int y = 0; y < m.length; y++)
            for (int x = 0; x < m[0].length; x++)
                if (m[y][x]) { mx += x; my += y; }
        mx /= area; my /= area;
        double uxx = 0, uyy = 0, uxy = 0;
        for (int y = 0; y < m.length; y++)
            for (int x = 0; x < m[0].length; x++)
                if (m[y][x]) {
                    uxx += (x - mx) * (x - mx);
                    uyy += (y - my) * (y - my);
                    uxy += (x - mx) * (y - my);
                }
        uxx /= area; uyy /= area; uxy /= area;
        double tr = uxx + uyy, det = uxx * uyy - uxy * uxy;
        double disc = Math.sqrt(Math.max(0, tr * tr / 4 - det));
        double l1 = tr / 2 + disc, l2 = tr / 2 - disc;
        if (l1 <= 1e-12) return 0;
        return Math.sqrt(Math.max(0, 1 - l2 / l1));
    }

    /** area / area of the convex hull. Like skimage, the hull is built from the midpoints of each pixel's
     *  four edges (centre +/- 0.5 along an axis), then pixels whose centre lies inside it are counted. Coordinates are
     *  doubled so everything stays in exact integer arithmetic. */
    static double solidity(boolean[][] m, double area) {
        java.util.Set<Long> seen = new java.util.HashSet<>();
        List<int[]> pts = new ArrayList<>();
        for (int y = 0; y < m.length; y++)
            for (int x = 0; x < m[0].length; x++)
                if (m[y][x])
                    for (int[] d : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) {
                        int px = 2 * x + d[0], py = 2 * y + d[1];
                        if (seen.add(((long) px << 32) | (py & 0xffffffffL))) pts.add(new int[]{px, py});
                    }
        if (pts.size() < 3) return 1.0;
        int[][] hull = convexHull(pts);
        long inside = 0;
        for (int y = 0; y < m.length; y++)
            for (int x = 0; x < m[0].length; x++)
                if (insideHull(hull, 2 * x, 2 * y)) inside++;
        return inside == 0 ? 1.0 : Math.min(1.0, area / inside);
    }

    // Andrew's monotone chain; returns hull in counter-clockwise order
    private static int[][] convexHull(List<int[]> pts) {
        pts.sort((a, b) -> a[0] != b[0] ? Integer.compare(a[0], b[0]) : Integer.compare(a[1], b[1]));
        int n = pts.size(), k = 0;
        int[][] H = new int[2 * n][];
        for (int i = 0; i < n; i++) {
            while (k >= 2 && cross(H[k - 2], H[k - 1], pts.get(i)) <= 0) k--;
            H[k++] = pts.get(i);
        }
        for (int i = n - 2, t = k + 1; i >= 0; i--) {
            while (k >= t && cross(H[k - 2], H[k - 1], pts.get(i)) <= 0) k--;
            H[k++] = pts.get(i);
        }
        return Arrays.copyOf(H, Math.max(1, k - 1));
    }

    private static long cross(int[] o, int[] a, int[] b) {
        return (long) (a[0] - o[0]) * (b[1] - o[1]) - (long) (a[1] - o[1]) * (b[0] - o[0]);
    }

    private static boolean insideHull(int[][] hull, int px, int py) {
        int n = hull.length;
        if (n < 3) return false;
        for (int i = 0; i < n; i++) {
            int[] a = hull[i], b = hull[(i + 1) % n];
            long c = (long) (b[0] - a[0]) * (py - a[1]) - (long) (b[1] - a[1]) * (px - a[0]);
            if (c < 0) return false;
        }
        return true;
    }
}
