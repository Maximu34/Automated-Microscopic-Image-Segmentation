package com.jainth.seg;

import java.util.Arrays;

/** Pixel-level (IoU, Dice, accuracy) and object-level (count accuracy, AP@IoU) metrics. */
public final class Metrics {
    public double iou, dice, pixelAcc, countAcc, ap50, map;
    public int gtCount, predCount, tp, fp, fn;

    public static Metrics compute(LabelImage gt, LabelImage pr) {
        if (gt.width != pr.width || gt.height != pr.height)
            throw new IllegalArgumentException("Size mismatch between GT and prediction");
        Metrics m = new Metrics();
        int n = gt.labels.length;
        long inter = 0, g = 0, p = 0, same = 0;
        int gmax = 0, pmax = 0;
        for (int i = 0; i < n; i++) {
            boolean a = gt.labels[i] > 0, b = pr.labels[i] > 0;
            if (a) g++;
            if (b) p++;
            if (a && b) inter++;
            if (a == b) same++;
            gmax = Math.max(gmax, gt.labels[i]);
            pmax = Math.max(pmax, pr.labels[i]);
        }
        long union = g + p - inter;
        m.iou = union == 0 ? 1.0 : (double) inter / union;
        m.dice = (g + p) == 0 ? 1.0 : 2.0 * inter / (g + p);
        m.pixelAcc = (double) same / n;

        // joint histogram of (gt label, pred label)
        long[][] joint = new long[gmax + 1][pmax + 1];
        for (int i = 0; i < n; i++)
            if (gt.labels[i] > 0 && pr.labels[i] > 0) joint[gt.labels[i]][pr.labels[i]]++;
        long[] ga = new long[gmax + 1], pa = new long[pmax + 1];
        for (int i = 0; i < n; i++) { ga[gt.labels[i]]++; pa[pr.labels[i]]++; }

        int gtN = 0, prN = 0;
        for (int i = 1; i <= gmax; i++) if (ga[i] > 0) gtN++;
        for (int j = 1; j <= pmax; j++) if (pa[j] > 0) prN++;
        m.gtCount = gtN; m.predCount = prN;
        m.countAcc = gtN == 0 ? (prN == 0 ? 1.0 : 0.0) : Math.max(0.0, 1.0 - Math.abs(gtN - prN) / (double) gtN);

        double[][] objectIou = new double[gmax + 1][pmax + 1];
        for (int i = 1; i <= gmax; i++) {
            if (ga[i] == 0) continue;
            for (int j = 1; j <= pmax; j++) {
                if (pa[j] == 0 || joint[i][j] == 0) continue;
                objectIou[i][j] = (double) joint[i][j] / (ga[i] + pa[j] - joint[i][j]);
            }
        }

        double sumAp = 0;
        for (int s = 0; s < 10; s++) {
            double threshold = 0.5 + 0.05 * s;
            int[] matchedPrediction = new int[pmax + 1];
            Arrays.fill(matchedPrediction, -1);
            int tp = 0;
            for (int i = 1; i <= gmax; i++) {
                if (ga[i] == 0) continue;
                boolean[] seen = new boolean[pmax + 1];
                if (augment(i, threshold, objectIou, matchedPrediction, seen, pmax)) tp++;
            }
            int fp = prN - tp, fn = gtN - tp;
            int d = tp + fp + fn;
            double ap = d == 0 ? 1.0 : (double) tp / d;
            sumAp += ap;
            if (s == 0) { m.ap50 = ap; m.tp = tp; m.fp = fp; m.fn = fn; }
        }
        m.map = sumAp / 10.0;
        return m;
    }

    // Kuhn augmenting-path algorithm: maximum-cardinality one-to-one matching
    // among object pairs whose IoU meets the selected threshold.
    private static boolean augment(int gtId, double threshold, double[][] iou,
                                   int[] matchedPrediction, boolean[] seen, int pmax) {
        for (int predId = 1; predId <= pmax; predId++) {
            if (seen[predId] || iou[gtId][predId] < threshold - 1e-12) continue;
            seen[predId] = true;
            if (matchedPrediction[predId] == -1 ||
                    augment(matchedPrediction[predId], threshold, iou, matchedPrediction, seen, pmax)) {
                matchedPrediction[predId] = gtId;
                return true;
            }
        }
        return false;
    }
}
