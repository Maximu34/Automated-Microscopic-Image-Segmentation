# Microscopy Segmentation

An end-to-end microscopy nuclei segmentation and biological feature-extraction project combining an OpenCV watershed baseline, a PyTorch U-Net, Java-based object measurements/evaluation, and a local interactive dashboard.

## Abstract

This project segments nuclei in microscopy images and compares a classical image-processing pipeline with a deep-learning U-Net. Python handles image preprocessing, dataset preparation, model training, inference, instance separation, and metric cross-checks. A Java command-line module extracts connected-component features and computes evaluation metrics. A local dashboard presents existing results and supports image analysis and video tracking.

## Project overview

The pipeline supports:
- Grayscale conversion, contrast normalization, denoising, and image resizing.
- Classical adaptive-thresholding and marker-controlled watershed segmentation using OpenCV/scikit-image.
- U-Net training with a combined BCE/Dice objective and augmentation.
- Distance-transform watershed post-processing to separate touching nuclei.
- Java connected-component analysis and measurements (area, perimeter, centroid, eccentricity, and solidity).
- Evaluation using IoU, Dice, pixel accuracy, count accuracy, AP@0.5, and mean AP over IoU thresholds.
- Interactive local dashboard for result review, uploaded-image inference, cell measurements, exports, and video tracking.

## Objectives

1. Build a reproducible microscopy nuclei segmentation workflow.
2. Compare a classical watershed baseline against a U-Net model.
3. Extract interpretable per-object morphological features.
4. Cross-check Java evaluation against an independent Python implementation.
5. Provide an interactive dashboard for visual inspection and inference.

## Technologies

- **Python 3.10+** — pipeline orchestration and scientific computing.
- **OpenCV, NumPy, SciPy, scikit-image, pandas, Matplotlib** — image processing, analysis, and plots.
- **PyTorch 2.0+** — U-Net training and inference.
- **Java 17+** — connected components, feature extraction, and evaluation.
- **HTML, CSS, JavaScript, Plotly** — dashboard UI and charts.
- **Jupyter / Google Colab** — optional GPU training notebook.

## Methodology

1. **Dataset:** DSB2018 / BBBC038 `stage1_train` images and instance masks.
2. **Preprocessing:** convert to grayscale, normalize contrast, denoise, resize to 256×256, and prepare instance-label maps.
3. **Classical baseline:** adaptive thresholding followed by marker-controlled watershed.
4. **Deep learning:** train a U-Net with BCE + Dice loss; infer foreground probability maps.
5. **Instance separation:** apply distance-transform watershed to split touching nuclei.
6. **Feature extraction:** Java connected-component analysis calculates object-level geometry.
7. **Evaluation:** compute per-image overlap/count metrics and object AP; compare Java and Python implementations.
8. **Presentation:** the dashboard reads bundled results and the trained model; it can also analyze uploaded images and videos.

## Folder structure

```text
Microscopy-Segmentation/
├── Python/                 # Python package, training, inference and analysis modules
├── Java/                   # Java source, Maven config and build scripts
├── Dashboard/              # Local dashboard server and static frontend
├── Notebooks/              # Colab/Jupyter training notebook
├── Results/                # Trained checkpoint, metrics, labels, plots and demo fallback
│   └── demo_outputs/       # Clearly labelled synthetic dashboard examples
├── data/                   # Dataset files are downloaded/generated locally
├── run_all.py              # Full pipeline runner
├── download_data.py        # Downloads the raw DSB2018 training set
├── README.md
├── requirements.txt
└── .gitignore
```

`Results/` is the runtime output directory used by the project scripts. It is intentionally retained at the repository root so the existing Python, Java, and dashboard workflows continue to use the same paths. Large raw data and regenerable processed-data caches are not bundled; download and regenerate them using the instructions below.

## Installation

Requirements: Python 3.10 or newer; JDK 17 or newer for Java evaluation; Git.

```bash
# Clone the repository, then enter it
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd Microscopy-Segmentation

# Create and activate a virtual environment (recommended)
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
```

For GPU training, install the PyTorch build matching your CUDA version from [the official PyTorch installer](https://pytorch.org/get-started/locally/). CPU inference is supported but training is slower.

## Dataset

The raw DSB2018 / BBBC038 `stage1_train` dataset and generated processed image/label cache are excluded from this GitHub package to keep the upload below 25 MB. The project recreates the processed data from the downloaded raw dataset. Download it from:

- [Kaggle Data Science Bowl 2018 dataset](https://www.kaggle.com/competitions/data-science-bowl-2018/data)
- Direct dataset download used by the included helper: [BBBC038 stage1_train ZIP](https://data.broadinstitute.org/bbbc/BBBC038/stage1_train.zip)
- [BBBC038 dataset information](https://bbbc.broadinstitute.org/BBBC038)

Run the included downloader from the repository root:

```bash
python download_data.py
```

It places the raw data under `data/raw/stage1_train/`. The bundled `Results/` directory retains the trained checkpoint, evaluation metrics, masks, and sample visualizations. To regenerate the training data cache, run the preprocessing command below after downloading the raw data.

## How to run

### Launch the dashboard (no retraining)

```bash
python Dashboard/server.py
```

Open [http://localhost:8000](http://localhost:8000). The bundled trained checkpoint is `Results/models/unet_best.pt`.

### Run or regenerate the pipeline

From the repository root:

```bash
python run_all.py --skip-train
```

The script downloads the DSB2018 dataset if it is not present, regenerates the processed data, and reuses the bundled trained model when available. To run individual stages manually:

```bash
cd Python
python -m seg.data_prep --raw ../data/raw/stage1_train
python -m seg.baseline
python -m seg.train --epochs 40 --base 32
python -m seg.predict
python -m seg.compare
cd ..
```

### Java evaluation

JDK 17+ is required. From the repository root:

```bash
# Windows
Java\build.bat
# macOS/Linux
bash Java/build.sh

java -cp Java/out com.jainth.seg.Main --pred Results/baseline/labels --gt Results/gt --out Results/baseline
java -cp Java/out com.jainth.seg.Main --pred Results/unet/labels --gt Results/gt --out Results/unet
```

### Google Colab training

Open `Notebooks/train_colab.ipynb` in Google Colab and follow its upload/runtime instructions to train on a GPU. The notebook expects the project folder and DSB2018 archive to be uploaded to the Colab session.

## Results and performance

The archive includes per-image Java and Python metrics for **102 test images**. The following are arithmetic means from the bundled `Results/*/metrics.csv` files; they are existing project results, not a new benchmark run during packaging.

| Metric (mean over 102 images) | Classical watershed | U-Net |
|---|---:|---:|
| IoU | 0.7321 | 0.7611 |
| Dice | 0.8290 | 0.8475 |
| Pixel accuracy | 0.9579 | 0.9664 |
| Count accuracy | 0.8011 | 0.8277 |
| AP@0.5 | 0.6590 | 0.6947 |
| mAP (IoU 0.50–0.95) | 0.3750 | 0.4685 |

The bundled Java/Python metric cross-check files agree to within approximately 1e-6 for the reported metrics. See `Results/comparison.png`, `Results/qualitative.png`, and `Results/training_curve.png` for visual summaries.

**Interpretation:** U-Net scores higher than the classical baseline on the bundled test split for the metrics above. Results depend on preprocessing, split, training configuration, and dataset. Synthetic examples under `Results/demo_outputs/` are dashboard demonstration data and must not be presented as experimental test results.

## Notes and limitations

- Measurements are in pixels / pixels² unless microscope calibration (µm per pixel) is supplied.
- Confidence maps are model probabilities, not calibrated biological confidence intervals.
- Video tracking IDs are provisional frame-to-frame associations and may switch during occlusion, contact, division, merging, or rapid motion.
- Segmentation and area changes are image-derived measurements, not biological conclusions.
- Do not run `Python/build_demo.py` on the working project data unless you intentionally want to regenerate synthetic dashboard examples; it is a demo-data builder.

## GitHub upload

```bash
git init
git add .
git commit -m "Prepare microscopy segmentation project"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

All files in this package are below GitHub's standard 100 MB per-file hard limit. The trained model is about 7.8 MB, so Git LFS is not required for the bundled checkpoint. If a future checkpoint exceeds 100 MB, track `*.pt` with Git LFS before committing it.

## License and dataset terms

Check the original code, dependency, and dataset licences before redistribution. The DSB2018/BBBC038 data is not included in this package; obtain it from the dataset provider and follow its terms.
