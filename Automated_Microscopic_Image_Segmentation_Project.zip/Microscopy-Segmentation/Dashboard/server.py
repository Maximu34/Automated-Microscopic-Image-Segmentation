"""Localhost dashboard for segmentation, live image analysis and video tracking.

    python Dashboard/server.py            ->  http://localhost:8000
    python Dashboard/server.py --port 8080 --no-browser

It reads whatever is in Results/ (written by the pipeline + Java tool). If Results/ is empty it
shows the bundled demo_Results/ (synthetic data) with a clear DEMO banner.
Progress % is computed from the files that really exist, nothing is hard-coded.
"""
import argparse
import csv
import sys
import json
import mimetypes
import re
import threading
import base64
import uuid
import time
from email.parser import BytesParser
from email.policy import default
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from Python.seg.inference import predict_image
from Python.seg.analysis import measure_cells, confidence_overlay
from Python.seg.baseline import segment as classical_segment
from Python.seg.report import write_csv, write_pdf
from Python.seg.tracking import process_video

import cv2
import numpy as np

STATIC = Path(__file__).resolve().parent / "static"
TYPES = {".js": "text/Javascript", ".css": "text/css", ".html": "text/html; charset=utf-8", ".json": "application/json"}  # Windows registry can mislabel .js
METHODS = ["baseline", "unet"]
METRIC_KEYS = ["iou", "dice", "pixel_acc", "count_acc", "ap50", "map"]
ANALYSIS_DIR = ROOT / "Results" / "interactive_analysis"
ANALYSIS_DIR.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------------- data access
def read_csv(path):
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        o = {}
        for k, v in r.items():
            try:
                o[k] = float(v)
            except (TypeError, ValueError):
                o[k] = v
        out.append(o)
    return out


class Source:
    """Decides which folder to show (real outputs, or the bundled demo)."""

    def __init__(self, force_demo=False):
        real = ROOT / "Results"
        demo = ROOT / "Results" / "demo_outputs"
        has_real = (real / "gt").exists() and any((real / "gt").glob("*.png"))
        if has_real and not force_demo:
            self.out, self.mode = real, "real"
            self.img_dir = ROOT / "data" / "processed" / "images"
        elif demo.exists():
            self.out, self.mode = demo, "demo"
            self.img_dir = demo / "images"
        else:
            self.out, self.mode, self.img_dir = real, "empty", ROOT / "data" / "processed" / "images"
        ids = sorted(p.stem for p in (self.out / "gt").glob("*.png")) if (self.out / "gt").exists() else []
        self.ids = ids
        self.synthetic = bool(ids) and all(i.startswith("synth") for i in ids)
        if self.mode == "real" and self.synthetic:
            self.mode = "synthetic"          # user ran the smoke test: still not real results


# ----------------------------------------------------------------------------- progress
def progress():
    """Milestones -> percent. Max auto-percent is 90; the last 10 is the written report / viva."""
    out = ROOT / "Results"
    proc = ROOT / "data" / "processed"
    ms = []

    def add(name, weight, done, detail):
        ms.append({"name": name, "weight": weight, "done": bool(done), "detail": detail})

    add("Review 1: problem, literature survey, design", 10, True, "Submitted")
    py = ROOT / "Python" / "seg"
    add("Python: pre-processing + classical baseline", 10,
        all((py / f).exists() for f in ["data_prep.py", "preprocess.py", "baseline.py", "postprocess.py"]), "Code complete")
    add("Python: U-Net model + training + prediction", 10,
        all((py / f).exists() for f in ["unet.py", "dataset.py", "train.py", "predict.py"]), "Code complete")
    add("Java tool: components, features, evaluation", 10,
        (ROOT / "Java" / "src" / "main" / "java" / "com" / "jainth" / "seg" / "Features.java").exists(),
        "Code complete, verified against scikit-image")
    add("Evaluation + comparison module", 10,
        (py / "metrics.py").exists() and (py / "compare.py").exists(), "Code complete")
    add("Website dashboard (this page)", 10, (ROOT / "Dashboard" / "server.py").exists(), "Running")

    splits = proc / "splits.json"
    real_data = False
    if splits.exists():
        try:
            s = json.loads(splits.read_text())
            allids = s.get("train", []) + s.get("val", []) + s.get("test", [])
            real_data = bool(allids) and not all(i.startswith("synth") for i in allids)
        except Exception:
            pass
    add("Real dataset (DSB2018) downloaded + pre-processed", 5, real_data,
        "data/processed/splits.json" if real_data else "Run: python run_all.py (step 1)")

    base_n = len(list((out / "baseline" / "labels").glob("*.png"))) if (out / "baseline" / "labels").exists() else 0
    add("Classical baseline run on real test set", 5, real_data and base_n > 0,
        f"{base_n} test images segmented" if base_n else "Not run yet")

    log = read_csv(out / "train_log.csv")
    trained = real_data and len(log) >= 10 and (out / "models" / "unet_best.pt").exists()
    add("U-Net trained on real data (10+ epochs)", 10, trained,
        f"{len(log)} epochs logged" if log else "Not trained yet")

    java_ok = all((out / m / f).exists() for m in METHODS for f in ("features.csv", "metrics.csv"))
    add("Java features + metrics for both methods", 5, real_data and java_ok,
        "features.csv + metrics.csv found" if java_ok else "Not run yet")

    add("Final comparison table + figures", 5, real_data and (out / "comparison.csv").exists(),
        "comparison.csv found" if (out / "comparison.csv").exists() else "Not generated yet")

    pct = sum(m["weight"] for m in ms if m["done"])
    ms.append({"name": "Final report + viva preparation (yours)", "weight": 10, "done": False,
               "detail": "Written by you after the results are in", "manual": True})
    return {"percent": pct, "max_auto": 90, "milestones": ms}


# ----------------------------------------------------------------------------- summary
def summary(src: Source):
    out = src.out
    res = {"mode": src.mode, "ids": src.ids, "progress": progress(), "methods": {}, "train_log": [],
           "dataset": {}}
    splits = ROOT / "data" / "processed" / "splits.json"
    if src.mode in ("real", "synthetic") and splits.exists():
        s = json.loads(splits.read_text())
        res["dataset"] = {k: len(v) for k, v in s.items()}
    elif (out / "splits.json").exists():
        s = json.loads((out / "splits.json").read_text())
        res["dataset"] = {k: len(v) for k, v in s.items()}
    res["dataset"]["name"] = "DSB2018 / BBBC038 stage1_train" if src.mode == "real" else "Synthetic nuclei (demo)"
    res["train_log"] = read_csv(out / "train_log.csv")
    for m in METHODS:
        rows = read_csv(out / m / "metrics.csv")
        origin = "Java"
        if not rows:
            rows, origin = read_csv(out / m / "metrics_python.csv"), "Python"
        if not rows:
            continue
        mean = {k: float(np.mean([r[k] for r in rows])) for k in METRIC_KEYS if k in rows[0]}
        feats = read_csv(out / m / "features.csv")
        res["methods"][m] = {
            "label": "Classical (threshold + watershed)" if m == "baseline" else "U-Net",
            "origin": origin, "mean": mean, "per_image": rows,
            "features": [{"image": f["image"], "area": f["area"], "perimeter": f["perimeter"],
                          "ecc": f["eccentricity"], "sol": f["solidity"]} for f in feats],
            "n_objects": len(feats),
        }
    return res


# ----------------------------------------------------------------------------- images
_rng = np.random.RandomState(7)
_LUT = _rng.randint(60, 255, (70000, 3)).astype(np.uint8)
_LUT[0] = (0, 0, 0)


def png(arr):
    ok, buf = cv2.imencode(".png", arr)
    return buf.tobytes()


def render(src: Source, kind, img_id):
    gray = cv2.imread(str(src.img_dir / f"{img_id}.png"), cv2.IMREAD_GRAYSCALE)
    if gray is None:
        return None
    if kind == "image":
        return png(gray)
    if kind.startswith("overlay_"):
        m = kind.split("_", 1)[1]
        lbl = cv2.imread(str(src.out / m / "labels" / f"{img_id}.png"), cv2.IMREAD_UNCHANGED)
        if lbl is None:
            return None
        rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        edges = np.zeros(lbl.shape, np.uint8)
        for i in np.unique(lbl):
            if i == 0:
                continue
            cs, _ = cv2.findContours((lbl == i).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            cv2.drawContours(edges, cs, -1, 255, 1)
        rgb[edges > 0] = (38, 89, 217) if m == "unet" else (229, 135, 57)   # BGR
        return png(rgb)
    folder = src.out / "gt" if kind == "gt" else src.out / kind / "labels"
    lbl = cv2.imread(str(folder / f"{img_id}.png"), cv2.IMREAD_UNCHANGED)
    if lbl is None:
        return None
    return png(_LUT[lbl.astype(np.int32) % len(_LUT)][:, :, ::-1])  # BGR for cv2


def surface(src: Source, img_id, n=64):
    gray = cv2.imread(str(src.img_dir / f"{img_id}.png"), cv2.IMREAD_GRAYSCALE)
    if gray is None:
        return None
    g = cv2.resize(gray, (n, n), interpolation=cv2.INTER_AREA)
    return {"z": g.astype(int).tolist()}


# ----------------------------------------------------------------------------- interactive analysis
def _png_b64(arr):
    ok, buf = cv2.imencode(".png", arr)
    if not ok: raise ValueError("Could not encode analysis image")
    return base64.b64encode(buf).decode("ascii")

def _multipart_file(handler):
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0 or length > 250 * 1024 * 1024:
        raise ValueError("Upload must be between 1 byte and 250 MB")
    raw = handler.rfile.read(length)
    content_type = handler.headers.get("Content-Type", "")
    msg = BytesParser(policy=default).parsebytes((f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode() + raw)
    if not msg.is_multipart(): raise ValueError("Please upload using the file picker")
    for part in msg.iter_parts():
        if part.get_filename(): return part.get_filename(), part.get_payload(decode=True)
    raise ValueError("No file was received")

def _safe_name(name):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", Path(name).name)[:100] or "upload"

# ----------------------------------------------------------------------------- http
class Handler(BaseHTTPRequestHandler):
    force_demo = False

    def log_message(self, *a):
        pass

    def send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                return self.send(200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
            if path.startswith("/static/"):
                f = (STATIC / path[len("/static/"):]).resolve()
                if STATIC.resolve() in f.parents and f.is_file():
                    return self.send(200, f.read_bytes(), TYPES.get(f.suffix, mimetypes.guess_type(f.name)[0] or "application/octet-stream"))
                return self.send(404, b"not found", "text/plain")
            if path.startswith("/analysis/"):
                rel = Path(path[len("/analysis/"):])
                f = (ANALYSIS_DIR / rel).resolve()
                if ANALYSIS_DIR.resolve() in f.parents and f.is_file():
                    return self.send(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream")
                return self.send(404, b"not found", "text/plain")
            if path == "/favicon.ico":
                return self.send(204, b"", "image/x-icon")
            src = Source(self.force_demo)
            if path == "/api/summary":
                return self.send(200, json.dumps(summary(src)).encode(), "application/json")
            m = re.fullmatch(r"/img/(image|gt|baseline|unet|overlay_baseline|overlay_unet)/([\w\-.]+)\.png", path)
            if m:
                data = render(src, m.group(1), m.group(2))
                return self.send(200, data, "image/png") if data else self.send(404, b"no image", "text/plain")
            m = re.fullmatch(r"/api/surface/([\w\-.]+)", path)
            if m:
                data = surface(src, m.group(1))
                return self.send(200, json.dumps(data).encode(), "application/json") if data else self.send(404, b"{}", "application/json")
            self.send(404, b"not found", "text/plain")
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:                              # keep the server alive, show the error
            self.send(500, f"server error: {e}".encode(), "text/plain")

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            filename, payload = _multipart_file(self)
            ext = Path(filename).suffix.lower()
            if path == "/api/analyze/image":
                if ext not in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
                    raise ValueError("Supported images: PNG, JPG, TIFF and BMP")
                arr = np.frombuffer(payload, np.uint8)
                image = cv2.imdecode(arr, cv2.IMREAD_UNCHANGED)
                if image is None: raise ValueError("The image could not be decoded")
                threshold = float(self.headers.get("X-Threshold", "0.5"))
                tiling = self.headers.get("X-Tiling", "false").lower() == "true"
                tta = self.headers.get("X-TTA", "false").lower() == "true"
                started = time.perf_counter()
                gray, prob, unet_lbl, mode = predict_image(image, threshold=threshold, tiling=tiling, tta=tta)
                selected_seconds = time.perf_counter() - started
                inference_comparison = None
                if tiling or tta:
                    base_started = time.perf_counter()
                    _, base_prob, base_lbl, base_mode = predict_image(gray, threshold=threshold, tiling=False, tta=False)
                    base_seconds = time.perf_counter() - base_started
                    inference_comparison = {"standard_mode": base_mode, "standard_seconds": base_seconds,
                        "selected_mode": mode, "selected_seconds": selected_seconds,
                        "standard_cells": int(base_lbl.max()), "selected_cells": int(unet_lbl.max()),
                        "binary_mask_agreement": float(np.mean((base_prob >= threshold) == (prob >= threshold)))}
                classical_lbl = classical_segment(gray)
                cells = measure_cells(unet_lbl)
                classical_cells = measure_cells(classical_lbl)
                conf = confidence_overlay(gray, prob)
                def color_labels(lbl):
                    rng = np.random.default_rng(19); lut = rng.integers(50,255,(max(2,int(lbl.max())+1),3),dtype=np.uint8); lut[0]=0
                    return lut[lbl.astype(np.int32)]
                ident = uuid.uuid4().hex
                csv_path = ANALYSIS_DIR / f"{ident}_cells.csv"
                pdf_path = ANALYSIS_DIR / f"{ident}_report.pdf"
                rows = [{"method":"U-Net", **r} for r in cells] + [{"method":"Classical", **r} for r in classical_cells]
                write_csv(csv_path, rows)
                write_pdf(pdf_path, "Microscopic image analysis", {"file":_safe_name(filename),"inference_mode":mode,"unet_cell_count":len(cells),"classical_cell_count":len(classical_cells),"threshold":threshold}, cells)
                result={"filename":_safe_name(filename),"mode":mode,"shape":list(gray.shape),"cell_count":len(cells),"classical_count":len(classical_cells),"inference_comparison":inference_comparison,"measurements":cells,"classical_measurements":classical_cells,"images":{"original":_png_b64(cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)),"unet_mask":_png_b64(color_labels(unet_lbl)),"unet_overlay":_png_b64(cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR) if False else cv2.addWeighted(cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR),.65,cv2.cvtColor(color_labels(unet_lbl),cv2.COLOR_RGB2BGR),.35,0)),"classical_mask":_png_b64(color_labels(classical_lbl)),"confidence":_png_b64(conf)},"downloads":{"csv":f"/analysis/{csv_path.name}","pdf":f"/analysis/{pdf_path.name}"}}
                body=json.dumps(result).encode(); return self.send(200,body,"application/json")
            if path == "/api/analyze/video":
                if ext not in {".mp4", ".avi", ".mov", ".mkv", ".mpeg", ".mpg"}:
                    raise ValueError("Supported videos: MP4, AVI, MOV and MKV")
                ident=uuid.uuid4().hex; src=ANALYSIS_DIR/f"{ident}_{_safe_name(filename)}"; src.write_bytes(payload)
                out=ANALYSIS_DIR/ident; out.mkdir(parents=True,exist_ok=True)
                summary=process_video(src,out,threshold=float(self.headers.get("X-Threshold","0.5")),tiling=self.headers.get("X-Tiling","false").lower()=="true",tta=self.headers.get("X-TTA","false").lower()=="true")
                import csv as _csv
                with (out/"frame_counts.csv").open(newline="",encoding="utf-8") as f: counts=list(_csv.DictReader(f))
                with (out/"tracks.csv").open(newline="",encoding="utf-8") as f: tracks=list(_csv.DictReader(f))
                pdf=ANALYSIS_DIR/f"{ident}_video_report.pdf"
                write_pdf(pdf,"Microscopy video tracking",summary,frame_counts=[{"time_seconds":float(r["time_seconds"]),"cell_count":int(r["cell_count"])} for r in counts])
                result={"summary":summary,"counts":counts,"tracks":tracks,"video":f"/analysis/{ident}/tracking.mp4","csv":f"/analysis/{ident}/tracks.csv","frame_csv":f"/analysis/{ident}/frame_counts.csv","track_summary_csv":f"/analysis/{ident}/track_summary.csv","pdf":f"/analysis/{pdf.name}"}
                body=json.dumps(result).encode(); return self.send(200,body,"application/json")
            return self.send(404,b"not found","text/plain")
        except Exception as e:
            body=json.dumps({"error":str(e)}).encode(); return self.send(400,body,"application/json")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--demo", action="store_true", help="force the bundled synthetic demo data")
    a = ap.parse_args()
    Handler.force_demo = a.demo
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    url = f"http://localhost:{a.port}"
    print(f"Dashboard running at {url}   (Ctrl+C to stop)")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
