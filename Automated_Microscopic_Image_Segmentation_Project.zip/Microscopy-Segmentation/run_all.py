"""One command for the whole project (Windows / Mac / Linux).

    python run_all.py                 download data -> prep -> baseline -> train -> predict -> Java -> compare
    python run_all.py --skip-train    reuse the already-trained model
    python run_all.py --epochs 30 --base 32
    python run_all.py --dashboard     also start the website at the end

Defaults: GPU -> 40 epochs, base 32.  CPU only -> 15 epochs, base 16 (slow, ~30-60 min).
"""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYDIR = ROOT / "Python"
PY = sys.executable


def sh(*cmd, cwd=PYDIR):
    print("\n>", " ".join(str(c) for c in cmd), flush=True)
    r = subprocess.run([str(c) for c in cmd], cwd=cwd)
    if r.returncode:
        raise SystemExit(f"\nStep failed (exit {r.returncode}). Read the error above this line.")


def build_java():
    if not shutil.which("javac"):
        raise SystemExit("javac not found. Install JDK 17+ (https://adoptium.net), reopen VS Code, run again.")
    out = ROOT / "Java" / "out"
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    srcs = [str(p) for p in (ROOT / "Java" / "src" / "main" / "java").rglob("*.java")]
    sh("javac", "-d", out, *srcs, cwd=ROOT)


def run_java():
    for m in ("baseline", "unet"):
        sh("java", "-cp", ROOT / "Java" / "out", "com.jainth.seg.Main",
           "--pred", ROOT / "Results" / m / "labels", "--gt", ROOT / "Results" / "gt",
           "--out", ROOT / "Results" / m, cwd=ROOT)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-train", action="store_true")
    ap.add_argument("--epochs", type=int)
    ap.add_argument("--base", type=int)
    ap.add_argument("--java-only", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--dashboard", action="store_true")
    a = ap.parse_args()

    if a.java_only:
        build_java()
        run_java()
        return

    try:
        import torch
        gpu = torch.cuda.is_available()
    except ImportError:
        raise SystemExit("PyTorch missing. Run:  pip install -r Python/requirements.txt")
    epochs = a.epochs or (40 if gpu else 15)
    base = a.base or (32 if gpu else 16)
    print(f"Device: {'GPU' if gpu else 'CPU (slow)'}  |  epochs={epochs}  base={base}")

    print("\n[1/6] Dataset")
    sh(PY, ROOT / "download_data.py", cwd=ROOT)
    print("\n[2/6] Pre-processing + classical baseline")
    sh(PY, "-m", "seg.data_prep", "--raw", ROOT / "data" / "raw" / "stage1_train")
    sh(PY, "-m", "seg.baseline")
    print("\n[3/6] U-Net training")
    if a.skip_train and (ROOT / "Results" / "models" / "unet_best.pt").exists():
        print("skipped (using existing model)")
    else:
        sh(PY, "-m", "seg.train", "--epochs", epochs, "--base", base, "--workers", 0)
    sh(PY, "-m", "seg.predict")
    print("\n[4/6] Java: features + metrics")
    build_java()
    run_java()
    print("\n[5/6] Comparison + validation")
    sh(PY, "-m", "seg.compare")
    sh(PY, "check_java_features.py", "unet")
    print("\n[6/6] Done. Start the website:   python Dashboard/server.py   ->  http://localhost:8000")
    if a.dashboard:
        sh(PY, ROOT / "Dashboard" / "server.py", cwd=ROOT)


if __name__ == "__main__":
    main()
